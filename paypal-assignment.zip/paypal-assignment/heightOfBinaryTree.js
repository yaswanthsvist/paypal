const heightOfBinaryTree=(node)=>{
    if(!node)return 0;
    const leftDepth=heightOfBinaryTree(node.left);
    const rightDepth=heightOfBinaryTree(node.right);
    return 1+ ((leftDepth>rightDepth)?leftDepth:rightDepth);
}

module.exports={
    heightOfBinaryTree
}