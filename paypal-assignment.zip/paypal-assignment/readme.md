# setup
```
npm i
```
# tests
```
npm test
```