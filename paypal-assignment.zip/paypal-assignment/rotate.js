const rotate=(list,k)=>{
    if(!list)return null;
    if(list.length===0)return list;
    const j=k%list.length;
    const newList=[...list.slice(j),...list.slice(0,j)];
    return newList
}

module.exports={
    rotate
}