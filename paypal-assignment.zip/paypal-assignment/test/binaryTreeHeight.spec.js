const {expect} =require( 'chai');
const {heightOfBinaryTree} = require('../heightOfBinaryTree');

describe('Height of Binary Tree', function () {
    it('tree with single branch', function () {
        const tree={name:'root',left:{left:{right:{}}}}
        expect(heightOfBinaryTree(tree)).to.equal(4)
    });
    it('tree with un even branches', function () {
        const tree={name:'root',right:{},left:{left:{right:{}}}}
        expect(heightOfBinaryTree(tree)).to.equal(4)
    });
    it('single node', function () {
        const tree={name:'root'}
        expect(heightOfBinaryTree(tree)).to.equal(1)
    });
});