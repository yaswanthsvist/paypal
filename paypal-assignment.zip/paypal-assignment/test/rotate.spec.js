
const {expect} =require( 'chai');
const {rotate} = require('../rotate');

describe('Array', function () {
  describe('rotate right', function () {
    it('should right shift', function () {
      expect(rotate([1,2,7,8,9],1)).to.eql([2,7,8,9,1]);
      expect(rotate([1,2,7,8,9],2)).to.eql([7,8,9,1,2]);
      expect(rotate([1,2,7,8,9],3)).to.eql([8,9,1,2,7]);
      expect(rotate([1,2,7,8,9],4)).to.eql([9,1,2,7,8]);
      expect(rotate([1,2,7,8,9],5)).to.eql([1,2,7,8,9]);
      expect(rotate([1,2,7,8,9],6)).to.eql([2,7,8,9,1]);
      expect(rotate([1,2,7,8,9],7)).to.eql([7,8,9,1,2]);
    });
    it('should right shift array with length 0', function () {
      expect(rotate([],1)).to.eql([]);
    });
    it('should right shift array with length 1', function () {
      expect(rotate([3],1)).to.eql([3]);
    });
    it('should right shift array with length 2', function () {
      expect(rotate([3,2],1)).to.eql([2,3]);
      expect(rotate([3,2],2)).to.eql([3,2]);
    });
    it('should right shift array by 0 times', function () {
      expect(rotate([1,2,7,8,9],0)).to.eql([1,2,7,8,9]);
      expect(rotate([3,2],0)).to.eql([3,2]);
    });
  });
});