// bellow function will only work for integers that are greater than 0
const bucketSort=(list,k)=>{
    const bucket=[];
    list.map(num=>bucket[num]=num)
    return bucket.filter(x=>x).map(x=>parseInt(x))
}
module.exports={
    bucketSort
}